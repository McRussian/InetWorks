#ifndef NUMBER_H
#define NUMBER_H

// Определение абстрактного типа number как double
typedef double number;

#endif // NUMBER_H
